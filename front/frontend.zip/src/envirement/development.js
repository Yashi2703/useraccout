export const config = {
    backEnd:"http://localhost:8018"
}